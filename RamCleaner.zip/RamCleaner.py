# -*- coding: utf-8 -*-
"""
RamCleaner - يفرّغ كاش الرام تلقائيًا عند وصول الاستهلاك لنسبة معينة (Windows).

التثبيت:   pip install pystray pillow psutil
التشغيل:   python RamCleaner.py   (هيطلب صلاحيات Administrator تلقائيًا)
"""
import ctypes
import io
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

APP_NAME = "RamCleaner"
FROZEN = getattr(sys, "frozen", False)   # True لما يتحول لملف exe
BASE_DIR = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
LOG_PATH = os.path.join(BASE_DIR, "ramcleaner.log")

RAMMAP_URL = "https://download.sysinternals.com/files/RAMMap.zip"
CHECK_INTERVAL = 5      # ثواني بين كل فحص
COOLDOWN = 60           # ثواني بعد كل تنظيف
RETRY_DELAY = 300       # ثواني قبل إعادة المحاولة عند الفشل
THRESHOLDS = (70, 80, 90)
DEFAULT_CONFIG = {"threshold": 80, "autostart": False}
CREATE_NO_WINDOW = 0x08000000


# ----------------------------------------------------------------- Admin ---
def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def pythonw_exe():
    w = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    return w if os.path.exists(w) else sys.executable


def elevate_and_exit():
    if FROZEN:
        exe, args = sys.executable, sys.argv[1:]
    else:
        exe, args = pythonw_exe(), [os.path.abspath(__file__)] + sys.argv[1:]
    result = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", exe, subprocess.list2cmdline(args), BASE_DIR, 0)
    sys.exit(0 if result > 32 else 1)


if os.name != "nt":
    sys.exit("RamCleaner يعمل على Windows فقط.")

if not is_admin():
    elevate_and_exit()

try:
    import psutil
    import pystray
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    ctypes.windll.user32.MessageBoxW(
        None, "المكتبات ناقصة. نفّذ الأمر:\n\npip install pystray pillow psutil",
        APP_NAME, 0x10)
    sys.exit(1)

# ------------------------------------------------------------------- Log ---
log = logging.getLogger(APP_NAME)
log.setLevel(logging.INFO)
_handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
log.addHandler(_handler)


# ---------------------------------------------------------------- Config ---
def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data.get("threshold"), int) and 1 <= data["threshold"] <= 99:
            cfg["threshold"] = data["threshold"]
        if isinstance(data.get("autostart"), bool):
            cfg["autostart"] = data["autostart"]
    except FileNotFoundError:
        pass
    except Exception as e:
        log.warning("config.json غير صالح، هيتم استخدام الافتراضي: %s", e)
    return cfg


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


# ---------------------------------------------------------------- RAMMap ---
def find_rammap():
    names = ("RAMMap64.exe", "RAMMap.exe") if sys.maxsize > 2**32 else ("RAMMap.exe",)
    for name in names:
        path = os.path.join(BASE_DIR, name)
        if os.path.isfile(path) and os.path.getsize(path) > 100_000:
            return path
    return None


def ensure_rammap():
    path = find_rammap()
    if path:
        return path

    log.info("RAMMap غير موجود، جاري التحميل من %s", RAMMAP_URL)
    req = urllib.request.Request(RAMMAP_URL, headers={"User-Agent": "Mozilla/5.0 RamCleaner"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        expected = resp.headers.get("Content-Length")
        data = resp.read()
    if expected and int(expected) != len(data):
        raise RuntimeError("التحميل ناقص (الحجم غير مطابق)")

    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if z.testzip() is not None:
            raise RuntimeError("ملف ZIP تالف")
        members = {n.lower(): n for n in z.namelist()}
        wanted = "rammap64.exe" if sys.maxsize > 2**32 else "rammap.exe"
        if wanted not in members:
            raise RuntimeError(f"{wanted} غير موجود داخل ملف ZIP")
        target = os.path.join(BASE_DIR, os.path.basename(members[wanted]))
        tmp = target + ".part"
        with z.open(members[wanted]) as src, open(tmp, "wb") as dst:
            shutil.copyfileobj(src, dst)
        os.replace(tmp, target)

    if os.path.getsize(target) < 100_000:
        os.remove(target)
        raise RuntimeError("RAMMap بعد الفك حجمه غير طبيعي")
    log.info("تم تحميل RAMMap: %s", target)
    return target


def run_rammap(exe, switch):
    r = subprocess.run(
        [exe, "-accepteula", switch],
        stdin=subprocess.DEVNULL, capture_output=True, timeout=120,
        creationflags=CREATE_NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError(f"RAMMap {switch} انتهى بكود {r.returncode}")


# --------------------------------------------------------------- Startup ---
def startup_lnk():
    return os.path.join(
        os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu",
        "Programs", "Startup", f"{APP_NAME}.lnk")


def startup_exists():
    return os.path.exists(startup_lnk())


def _ps_quote(s):
    return s.replace("'", "''")


def create_startup_shortcut():
    if FROZEN:
        target, arguments = sys.executable, ""
    else:
        target, arguments = pythonw_exe(), '"%s"' % os.path.abspath(__file__)
    ps = (
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}');"
        "$s.TargetPath='{target}';$s.Arguments='{args}';"
        "$s.WorkingDirectory='{wd}';$s.Save()"
    ).format(lnk=_ps_quote(startup_lnk()), target=_ps_quote(target),
             args=_ps_quote(arguments), wd=_ps_quote(BASE_DIR))
    subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
        check=True, stdin=subprocess.DEVNULL, capture_output=True,
        creationflags=CREATE_NO_WINDOW)


def remove_startup_shortcut():
    if startup_exists():
        os.remove(startup_lnk())


# ------------------------------------------------------------------ Icon ---
COLORS = {"ok": (46, 160, 67), "high": (218, 54, 51), "cleaning": (230, 170, 20)}


def load_font(size):
    for name in ("arialbd.ttf", "arial.ttf", "segoeuib.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def make_icon(percent, state):
    size = 64
    img = Image.new("RGBA", (size, size), COLORS[state] + (255,))
    draw = ImageDraw.Draw(img)
    text = str(percent)
    font = load_font(46 if len(text) <= 2 else 34)
    fg = (0, 0, 0) if state == "cleaning" else (255, 255, 255)
    box = draw.textbbox((0, 0), text, font=font)
    w, h = box[2] - box[0], box[3] - box[1]
    draw.text(((size - w) / 2 - box[0], (size - h) / 2 - box[1]), text, font=font, fill=fg)
    return img


# ------------------------------------------------------------------- App ---
class RamCleaner:
    def __init__(self):
        self.cfg = load_config()
        self.stop_event = threading.Event()
        self.icon = None
        self.usage = psutil.virtual_memory().percent
        self.armed = True        # لازم الاستهلاك ينزل تحت النسبة قبل التنظيف التالي
        self.last_clean = 0.0
        self.retry_at = 0.0
        self.cleaning = False

    # ---- helpers
    def state(self):
        if self.cleaning:
            return "cleaning"
        return "high" if self.usage >= self.cfg["threshold"] else "ok"

    def refresh_icon(self):
        if not self.icon:
            return
        pct = int(round(self.usage))
        self.icon.icon = make_icon(pct, self.state())
        self.icon.title = f"{APP_NAME} - RAM {pct}% (التنظيف عند {self.cfg['threshold']}%)"

    def notify(self, message):
        try:
            if self.icon:
                self.icon.notify(message, APP_NAME)
        except Exception:
            log.exception("فشل عرض الإشعار")

    # ---- cleaning
    def clean(self):
        before = self.usage
        self.cleaning = True
        self.refresh_icon()
        try:
            exe = ensure_rammap()
            for switch in ("-Ew", "-Et"):
                run_rammap(exe, switch)
            time.sleep(2)
            after = psutil.virtual_memory().percent
            self.usage = after
            self.last_clean = time.time()
            self.retry_at = 0.0
            self.armed = False
            log.info("CLEAN | before=%.1f%% | after=%.1f%% | OK", before, after)
            if after < before:
                self.notify(f"تم التنظيف، الاستهلاك نزل من {before:.0f}% إلى {after:.0f}%")
            else:
                self.notify(f"تم التنظيف، الاستهلاك قبل {before:.0f}% وبعد {after:.0f}%")
        except Exception as e:
            self.retry_at = time.time() + RETRY_DELAY
            log.error("CLEAN | before=%.1f%% | FAILED: %s | إعادة المحاولة بعد %ds",
                      before, e, RETRY_DELAY)
            self.notify(f"فشل التنظيف: {str(e)[:100]}\nإعادة المحاولة بعد 5 دقايق")
        finally:
            self.cleaning = False

    # ---- monitor loop
    def monitor(self):
        log.info("START | threshold=%d%%", self.cfg["threshold"])
        while not self.stop_event.is_set():
            try:
                self.usage = psutil.virtual_memory().percent
                threshold = self.cfg["threshold"]
                if self.usage < threshold:
                    self.armed = True
                now = time.time()
                if (self.usage >= threshold and self.armed
                        and now - self.last_clean >= COOLDOWN
                        and now >= self.retry_at):
                    self.clean()
                self.refresh_icon()
            except Exception:
                log.exception("خطأ في حلقة المراقبة")
            self.stop_event.wait(CHECK_INTERVAL)

    # ---- tray menu actions
    def set_threshold(self, value):
        def action(icon, item):
            self.cfg["threshold"] = value
            self.armed = True
            try:
                save_config(self.cfg)
            except Exception:
                log.exception("فشل حفظ config.json")
            log.info("CONFIG | threshold=%d%%", value)
            self.refresh_icon()
        return action

    def threshold_checked(self, value):
        return lambda item: self.cfg["threshold"] == value

    def open_log(self, icon, item):
        try:
            os.startfile(LOG_PATH)
        except Exception:
            log.exception("فشل فتح ملف الـ log")

    def toggle_startup(self, icon, item):
        enable = not startup_exists()
        try:
            if enable:
                create_startup_shortcut()
            else:
                remove_startup_shortcut()
            self.cfg["autostart"] = enable
            save_config(self.cfg)
            log.info("CONFIG | autostart=%s", enable)
        except Exception as e:
            log.error("فشل تغيير التشغيل التلقائي: %s", e)
            self.notify(f"فشل تغيير التشغيل التلقائي: {str(e)[:100]}")

    def quit(self, icon, item):
        log.info("EXIT")
        self.stop_event.set()
        icon.stop()

    # ---- run
    def run(self):
        if self.cfg["autostart"]:
            try:
                create_startup_shortcut()   # تحديث المسار لو السكريبت اتنقل
            except Exception as e:
                log.error("فشل تحديث اختصار Startup: %s", e)

        threshold_menu = pystray.Menu(*[
            pystray.MenuItem(f"{v}%", self.set_threshold(v),
                             checked=self.threshold_checked(v), radio=True)
            for v in THRESHOLDS
        ])
        menu = pystray.Menu(
            pystray.MenuItem("نسبة التشغيل", threshold_menu),
            pystray.MenuItem("فتح ملف الـ log", self.open_log),
            pystray.MenuItem("تشغيل تلقائي مع Windows", self.toggle_startup,
                             checked=lambda item: startup_exists()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("خروج", self.quit),
        )
        self.icon = pystray.Icon(APP_NAME, make_icon(int(round(self.usage)), self.state()),
                                 APP_NAME, menu)

        def setup(icon):
            icon.visible = True
            threading.Thread(target=self.monitor, daemon=True).start()

        self.icon.run(setup=setup)


def single_instance():
    """يمنع تشغيل نسختين من البرنامج في نفس الوقت."""
    global _mutex
    _mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\RamCleaner_SingleInstance")
    return ctypes.windll.kernel32.GetLastError() != 183  # ERROR_ALREADY_EXISTS


if __name__ == "__main__":
    if single_instance():
        RamCleaner().run()
