@echo off
chcp 65001 >nul
echo === بناء RamCleaner.exe ===
python -m pip install --upgrade pystray pillow psutil pyinstaller
if errorlevel 1 goto :fail
python -m PyInstaller --onefile --noconsole --uac-admin --clean --name RamCleaner RamCleaner.py
if errorlevel 1 goto :fail
echo.
echo تم! الملف الجاهز: dist\RamCleaner.exe
pause
exit /b 0
:fail
echo حصل خطأ في البناء.
pause
exit /b 1
